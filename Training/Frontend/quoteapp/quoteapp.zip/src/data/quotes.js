export const quotes = [{
        quote: "You’re off to great places, today is your day. Your mountain is waiting, so get on your way.",
        author: "Dr. Seuss"
    },
    {
        quote: "You always pass failure on the way to success.",
        author: "Mickey Rooney"
    }, {
        quote: "No one is perfect - that’s why pencils have erasers.",
        author: "Wolfgang Riebe"
    }, {
        quote: "Winning doesn’t always mean being first. Winning means you’re doing better than you’ve done before",
        author: "Bonnie Blair"
    }, {
        quote: "You’re braver than you believe, and stronger than you seem, and smarter than you think.",
        author: "A.A. Mine"
    }
]