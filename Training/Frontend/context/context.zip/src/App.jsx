
import './App.css';
import ComA from './Components/ComA';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <ComA />
      </header>
    </div>
  );
}

export default App; //default
