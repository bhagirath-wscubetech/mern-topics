import React from 'react'
import ComB from './ComB'
export default function ComA() {
    return (
        <>
            <div>ComA</div>
            <ComB/>
        </>
    )
}
